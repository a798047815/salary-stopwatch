// 全局配置
let config = {
  dailySalary: 300,
  workStartTime: '09:00',
  workEndTime: '18:00',
  breakStartTime: '12:00',
  breakDuration: 60,
  currency: '¥'
}

// 全局状态
let state = {
  isRunning: false,
  currentEarnings: 0,
  timer: null,
  lastUpdateTime: null,
  lastDate: null,
  earningsPerSecond: 0,
  milestones: [
    { amount: 10, name: '开工红包', icon: '🧧' },
    { amount: 30, name: '咖啡自由', icon: '☕' },
    { amount: 50, name: '午餐达标', icon: '🍚' },
    { amount: 100, name: '下午茶', icon: '🍰' },
    { amount: 200, name: '下班自由', icon: '🎉' },
    { amount: 500, name: '日入五百', icon: '💪' },
    { amount: 1000, name: '日入千薪', icon: '🏆' }
  ]
}

// 初始化
function init() {
  loadConfig()
  calculateEarningsPerSecond()
  updateUI()
  startTimer()
}

// 加载配置
function loadConfig() {
  const saved = localStorage.getItem('salaryConfig')
  if (saved) {
    config = { ...config, ...JSON.parse(saved) }
  }
  
  // 更新设置表单
  document.getElementById('dailySalary').value = config.dailySalary
  document.getElementById('workStartTime').value = config.workStartTime
  document.getElementById('workEndTime').value = config.workEndTime
  document.getElementById('breakStartTime').value = config.breakStartTime
  document.getElementById('breakDuration').value = config.breakDuration
  document.getElementById('currency').value = config.currency
  
  // 更新显示
  document.getElementById('currencySymbol').textContent = config.currency
  document.getElementById('workTimeValue').textContent = `${config.workStartTime} - ${config.workEndTime}`
}

// 保存配置
function saveConfig() {
  localStorage.setItem('salaryConfig', JSON.stringify(config))
}

// 计算每秒收入
function calculateEarningsPerSecond() {
  const [startHour, startMin] = config.workStartTime.split(':').map(Number)
  const [endHour, endMin] = config.workEndTime.split(':').map(Number)
  
  let workSeconds = (endHour * 60 + endMin) - (startHour * 60 + startMin)
  workSeconds -= config.breakDuration || 0
  workSeconds *= 60
  
  if (workSeconds > 0) {
    state.earningsPerSecond = config.dailySalary / workSeconds
  }
}

// 启动计时器
function startTimer() {
  if (state.timer) return
  
  state.isRunning = true
  document.getElementById('toggleBtn').textContent = '⏸ 暂停'
  document.getElementById('toggleBtn').className = 'toggle-btn stop'
  
  state.timer = setInterval(() => {
    updateEarnings()
  }, 1000)
}

// 停止计时器
function stopTimer() {
  if (state.timer) {
    clearInterval(state.timer)
    state.timer = null
  }
  
  state.isRunning = false
  document.getElementById('toggleBtn').textContent = '▶️ 开始赚钱'
  document.getElementById('toggleBtn').className = 'toggle-btn start'
}

// 切换计时器
function toggleTimer() {
  if (state.isRunning) {
    stopTimer()
  } else {
    startTimer()
  }
}

// 更新收入
function updateEarnings() {
  const now = new Date()
  const currentTime = now.getTime()
  const today = now.getFullYear() * 10000 + (now.getMonth() + 1) * 100 + now.getDate()
  
  // 新的一天，重置收入
  if (!state.lastDate || state.lastDate !== today) {
    state.currentEarnings = 0
  }
  
  const currentHour = now.getHours()
  const currentMin = now.getMinutes()
  const currentSec = now.getSeconds()
  const currentMinutes = currentHour * 60 + currentMin
  const startMinutes = config.workStartTime.split(':').map(Number).reduce((h, m) => h * 60 + m, 0)
  const endMinutes = config.workEndTime.split(':').map(Number).reduce((h, m) => h * 60 + m, 0)
  
  // 午休时间
  const breakStartMinTotal = config.breakStartTime.split(':').map(Number).reduce((h, m) => h * 60 + m, 0)
  const breakEndMinTotal = breakStartMinTotal + config.breakDuration
  
  const inWorkTime = currentMinutes >= startMinutes && currentMinutes < endMinutes
  const inBreakTime = currentMinutes >= breakStartMinTotal && currentMinutes < breakEndMinTotal
  
  // 增加收入
  if (inWorkTime && !inBreakTime && state.isRunning) {
    if (state.lastUpdateTime) {
      const secondsPassed = Math.floor((currentTime - state.lastUpdateTime) / 1000)
      state.currentEarnings += state.earningsPerSecond * secondsPassed
    } else {
      // 计算今天已经工作的时间
      let secondsWorked = (currentMinutes - startMinutes) * 60 + currentSec
      if (currentMinutes > breakStartMinTotal) {
        secondsWorked -= config.breakDuration * 60
      }
      if (secondsWorked < 0) secondsWorked = 0
      state.currentEarnings = state.earningsPerSecond * secondsWorked
    }
  }
  
  // 更新UI
  updateUI()
  
  state.lastUpdateTime = currentTime
  state.lastDate = today
}

// 更新UI
function updateUI() {
  const now = new Date()
  const currentHour = now.getHours()
  const currentMin = now.getMinutes()
  const currentSec = now.getSeconds()
  const currentMinutes = currentHour * 60 + currentMin
  
  const startMinutes = config.workStartTime.split(':').map(Number).reduce((h, m) => h * 60 + m, 0)
  const endMinutes = config.workEndTime.split(':').map(Number).reduce((h, m) => h * 60 + m, 0)
  const breakStartMinTotal = config.breakStartTime.split(':').map(Number).reduce((h, m) => h * 60 + m, 0)
  const breakEndMinTotal = breakStartMinTotal + config.breakDuration
  
  // 计算进度
  let progressPercent = 0
  if (currentMinutes >= endMinutes) {
    progressPercent = 100
  } else {
    let totalWorkSeconds = (endMinutes - startMinutes) * 60 - config.breakDuration * 60
    let secondsWorked = (currentMinutes - startMinutes) * 60 + currentSec
    if (currentMinutes > breakStartMinTotal) {
      secondsWorked -= config.breakDuration * 60
    }
    if (secondsWorked > 0) {
      progressPercent = Math.min(100, (secondsWorked / totalWorkSeconds) * 100)
    }
  }
  
  // 距下班时间
  let remainingTime = ''
  let expectedEarnings = ''
  if (currentMinutes < endMinutes) {
    let remainingMinutes = endMinutes - currentMinutes
    if (currentMinutes < breakEndMinTotal && currentMinutes >= breakStartMinTotal) {
      remainingMinutes -= (breakEndMinTotal - currentMinutes)
    } else if (currentMinutes < breakStartMinTotal) {
      remainingMinutes -= config.breakDuration
    }
    remainingMinutes = Math.max(0, remainingMinutes)
    
    const hours = Math.floor(remainingMinutes / 60)
    const mins = Math.floor(remainingMinutes % 60)
    remainingTime = `距下班 ${hours}小时${mins}分钟`
    
    // 预计收入
    expectedEarnings = (remainingMinutes / 60 * config.dailySalary / ((endMinutes - startMinutes - config.breakDuration) / 60)).toFixed(0)
  } else {
    remainingTime = '已下班'
  }
  
  // 工作时长
  let workSeconds = 0
  const inWorkTime = currentMinutes >= startMinutes && currentMinutes < endMinutes
  const inBreakTime = currentMinutes >= breakStartMinTotal && currentMinutes < breakEndMinTotal
  
  if (inWorkTime && !inBreakTime) {
    let totalWorkSeconds = (endMinutes - startMinutes) * 60 - config.breakDuration * 60
    let secondsWorked = (currentMinutes - startMinutes) * 60 + currentSec
    if (currentMinutes > breakStartMinTotal) {
      secondsWorked -= config.breakDuration * 60
    }
    workSeconds = Math.max(0, secondsWorked)
  }
  
  const workHours = Math.floor(workSeconds / 3600)
  const workMins = Math.floor((workSeconds % 3600) / 60)
  const workSecs = workSeconds % 60
  
  // 下一个里程碑
  let nextMilestone = state.milestones.find(m => m.amount > state.currentEarnings)
  if (!nextMilestone) nextMilestone = { amount: '-', name: '已满级', icon: '🌟' }
  
  // 更新DOM
  document.getElementById('currentEarnings').textContent = state.currentEarnings.toFixed(2)
  document.getElementById('workTime').textContent = `${String(workHours).padStart(2, '0')}:${String(workMins).padStart(2, '0')}:${String(workSecs).padStart(2, '0')}`
  document.getElementById('remainingTime').textContent = remainingTime
  document.getElementById('expectedEarnings').textContent = expectedEarnings ? `预计赚 ${config.currency}${expectedEarnings}` : ''
  document.getElementById('progressBar').style.width = `${progressPercent.toFixed(0)}%`
  document.getElementById('progressText').textContent = `${progressPercent.toFixed(0)}%`
  document.getElementById('milestoneIcon').textContent = nextMilestone.icon
  document.getElementById('milestoneAmount').textContent = `${config.currency}${nextMilestone.amount}`
  document.getElementById('milestoneName').textContent = nextMilestone.name
}

// 打开设置
function openSettings() {
  document.getElementById('settingsModal').classList.add('show')
}

// 关闭设置
function closeSettings() {
  document.getElementById('settingsModal').classList.remove('show')
}

// 保存设置
function saveSettings() {
  config.dailySalary = parseFloat(document.getElementById('dailySalary').value) || 0
  config.workStartTime = document.getElementById('workStartTime').value
  config.workEndTime = document.getElementById('workEndTime').value
  config.breakStartTime = document.getElementById('breakStartTime').value
  config.breakDuration = parseInt(document.getElementById('breakDuration').value) || 0
  config.currency = document.getElementById('currency').value
  
  saveConfig()
  calculateEarningsPerSecond()
  
  // 更新显示
  document.getElementById('currencySymbol').textContent = config.currency
  document.getElementById('workTimeValue').textContent = `${config.workStartTime} - ${config.workEndTime}`
  
  closeSettings()
  
  // 提示
  alert('设置已保存')
}

// 点击模态框外部关闭
window.onclick = function(event) {
  const modal = document.getElementById('settingsModal')
  if (event.target == modal) {
    closeSettings()
  }
}

// 初始化
document.addEventListener('DOMContentLoaded', init)
